import os
import biomc_pp as embed_biomc_pp
import numpy as np
import matplotlib.pyplot as plt

OUT = os.environ["OUT_FOLDER"]
NAME = os.environ["BATCH_NAME"]


def quick_check(time, pp):
    X = pp.get_biomass_concentration()[:, 0]
    C = pp.get_concentrations(embed_biomc_pp.Phase.Liquid)
    S = C[:, 0, 0]
    plt.figure()
    plt.plot(time, X, "k", label="x")
    plt.plot(time, S, label="s")
    plt.legend()


def __udf_entry_point(name: str, root: str):
    pp = embed_biomc_pp.PostProcess(name, root)
    time = embed_biomc_pp.check_time_unit(pp)
    quick_check(time, pp)
    plt.show()


__udf_entry_point(NAME, OUT)
