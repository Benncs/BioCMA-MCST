import handle_module
import os
import numpy as np
import sys


def do_run():
    run = False
    if len(sys.argv) == 2:
        if sys.argv[1] == "r":
            run = True
    return run


def _check_startup():
    handle_module.pyinit_handle(10)


def check():
    if handle_module.get_version() != [0, 9, 5]:
        print(
            f"Warning: Script was written for v0.9.5, used {handle_module.get_version()}"
        )


def run(sim, params, out_folder, cma_path, _f_init):
    os.makedirs(f"{out_folder}/{sim}", exist_ok=True)
    S_feed = 5
    eps = 15 / 100
    vG = eps * 20e-3 / (1 - eps)
    dgas = 100 / 3600
    liquid_flow_rate = 0
    # Config
    params = handle_module.make_params(*params)
    handle = handle_module.init_simulation(out_folder, sim, cma_path, params)
    handle_module.set_initial_concentrations(handle, *_f_init)
    handle_module.set_liquid_feed_constant(handle, liquid_flow_rate, S_feed, 0, 0)
    handle_module.set_gas_feed_constant(handle, vG * dgas, 300e-3, 1, 0)
    handle_module.register_model_name(handle, "two_meta_nb")
    rc = handle_module.apply(handle, False)

    if not rc[0]:
        print(rc[1])
        return -1
    rc = handle_module.exec(handle)
    return 0
