import handle_module
import os
import numpy as np
import sys


def do_run():
    run = False
    if len(sys.argv) == 2:
        if sys.argv[1] == "r":
            run = True
    return run


def _check_startup():
    handle_module.pyinit_handle(10)


def check():
    if handle_module.get_version() != [0, 9, 5]:
        print(
            f"Warning: Script was written for v0.9.5, used {handle_module.get_version()}"
        )


def _initial_condition(n_compartment: int):
    liquid_concentration_0 = np.zeros((4, n_compartment))
    liquid_concentration_0[0, :] = 1
    liquid_concentration_0[1, :] = 9e-3

    gas_concentration = np.zeros((4, n_compartment))
    gas_concentration[1, :] = 300e-3
    return (liquid_concentration_0, gas_concentration)


def run(sim, out_folder, cma_path):
    os.makedirs(f"{out_folder}/{sim}", exist_ok=True)
    n_compartment = 1
    S_feed = 5
    nh = 40
    params = handle_module.make_params(
        biomass_initial_concentration=0.06,
        final_time=int(nh * 3600),
        delta_time=0.1,
        number_particle=100000,
        number_exported_result=50,
        save_serde=1,
    )

    handle = handle_module.init_simulation(out_folder, sim, cma_path, params)

    handle_module.set_initial_concentrations(handle, *_initial_condition(n_compartment))

    eps = 15 / 100
    vG = eps * 20e-3 / (1 - eps)
    dgas = 100 / 3600
    liquid_flow_rate = 0
    handle_module.set_liquid_feed_constant(handle, liquid_flow_rate, S_feed, 0, 0)
    handle_module.set_gas_feed_constant(handle, vG * dgas, 300e-3, 1, 0)

    handle_module.register_model_name(handle, "two_meta_nb")

    rc = handle_module.apply(handle, False)

    if not rc[0]:
        print(rc[1])
        return -1
    rc = handle_module.exec(handle)
    return 0
