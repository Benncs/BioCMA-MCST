c_config = {"OUT_FOLDER": "out", "CMA_PATH": "./cma_data/high_kla/"}
