"""
Simulation for $SIMULATION_NAME

$DESCRIPTION

Date: $DATE
Author: $AUTHOR
"""

import os
from utils import run, check, do_run

OUT_FOLDER = "out"
CMA_PATH = "./cma_data/high_kla/"

if __name__ == "__main__":
    os.environ["KOKKOS_NUM_THREADS"] = "20"
    simulation_name = "$SIMFILENAME"
    check()

    params = {
        "biomass_initial_concentration": 0.06,
        "final_time": int(1 * 3600),
        "delta_time": 0.1,
        "number_particle": 10000,
        "number_exported_result": 10,
        "save_serde": 1,
    }

    if do_run():
        run(simulation_name, params, OUT_FOLDER, CMA_PATH)
