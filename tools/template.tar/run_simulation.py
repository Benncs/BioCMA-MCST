"""
Simulation for $SIMULATION_NAME

$DESCRIPTION

Date: $DATE
Author: $AUTHOR
"""

import os
from utils import run, check, do_run
import numpy as np

from config import c_config

OUT_FOLDER = c_config["OUT_FOLDER"]
CMA_PATH = c_config["CMA_PATH"]

SIMULATION_NAME = "$SIMFILENAME"


def initial_condition(n_compartment: int):
    liquid_concentration_0 = np.zeros((4, n_compartment))
    liquid_concentration_0[0, :] = 1
    liquid_concentration_0[1, :] = 9e-3
    gas_concentration = np.zeros((4, n_compartment))
    gas_concentration[1, :] = 300e-3
    return (liquid_concentration_0, gas_concentration)


if __name__ == "__main__":
    os.environ["KOKKOS_NUM_THREADS"] = "6"
    check()

    params = {
        "biomass_initial_concentration": 0.06,
        "final_time": int(1 * 3600),
        "delta_time": 0.1,
        "number_particle": 10000,
        "number_exported_result": 10,
        "save_serde": 1,
    }

    if do_run():
        f_init = initial_condition(1)
        run(SIMULATION_NAME, params, OUT_FOLDER, CMA_PATH, f_init)
