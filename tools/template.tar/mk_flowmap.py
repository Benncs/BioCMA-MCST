import cmtool
from typing import Optional, Tuple
from cmtool.generate import generate_0D_set_from_fraction
import numpy as np
from cmtool.cma_case import cma_case_paths, CMAExportType
import os

name = "mono"
os.makedirs(f"./cma_data/{name}", exist_ok=True)

_case = generate_0D_set_from_fraction(f"./cma_data/{name}", 20e-3,0,0)
print(_case)
cmtool.cma_case.mk_write_cma_case(
    f"./cma_data/{name}/cma_case", [1, 0, 0], f"{name}", cma_path=_case
)
